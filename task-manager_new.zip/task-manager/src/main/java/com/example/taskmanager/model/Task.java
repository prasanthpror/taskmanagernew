package com.example.taskmanager.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "tasks")
public class Task {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 150)
    private String title;

    @Column(length = 2000)
    private String description;

    private LocalDate dueDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TaskStatus status = TaskStatus.TODO;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    protected Task() {}
    public Task(String title, String description, LocalDate dueDate, TaskStatus status, User user) {
        this.title = title; this.description = description; this.dueDate = dueDate;
        this.status = status == null ? TaskStatus.TODO : status; this.user = user;
    }
    public void update(String title, String description, LocalDate dueDate, TaskStatus status) {
        this.title = title; this.description = description; this.dueDate = dueDate; this.status = status;
    }
    public Long getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public LocalDate getDueDate() { return dueDate; }
    public TaskStatus getStatus() { return status; }
    public User getUser() { return user; }
}
