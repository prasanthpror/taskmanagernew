package com.example.taskmanager.service;

import com.example.taskmanager.dto.TaskRequest;
import com.example.taskmanager.dto.TaskResponse;
import java.util.List;

public interface TaskService {
    TaskResponse create(TaskRequest request, String username);
    List<TaskResponse> getAll(String username);
    TaskResponse getOne(Long id, String username);
    TaskResponse update(Long id, TaskRequest request, String username);
    void delete(Long id, String username);
}
