package com.example.taskmanager.service;

import com.example.taskmanager.model.User;

public interface UserService {
    User register(String username, String rawPassword);
    User getByUsername(String username);
}
