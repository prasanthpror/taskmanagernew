package com.example.taskmanager.dto;

import com.example.taskmanager.model.TaskStatus;
import java.time.LocalDate;

public record TaskResponse(Long id, String title, String description, LocalDate dueDate, TaskStatus status) {}
