package com.example.taskmanager.service;

import com.example.taskmanager.dto.TaskRequest;
import com.example.taskmanager.dto.TaskResponse;
import com.example.taskmanager.model.Task;
import com.example.taskmanager.model.TaskStatus;
import com.example.taskmanager.model.User;
import com.example.taskmanager.repository.TaskRepository;
import com.example.taskmanager.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@Service
@Transactional
public class TaskServiceImpl implements TaskService {
    private final TaskRepository tasks;
    private final UserRepository users;

    public TaskServiceImpl(TaskRepository tasks, UserRepository users) {
        this.tasks = tasks; this.users = users;
    }
    private User owner(String username) {
        return users.findByUsername(username)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "User not found"));
    }
    private Task ownedTask(Long id, String username) {
        return tasks.findByIdAndUser_Username(id, username)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found"));
    }
    private TaskResponse toResponse(Task t) {
        return new TaskResponse(t.getId(), t.getTitle(), t.getDescription(), t.getDueDate(), t.getStatus());
    }
    @Override public TaskResponse create(TaskRequest r, String username) {
        Task t = new Task(r.title(), r.description(), r.dueDate(),
            r.status() == null ? TaskStatus.TODO : r.status(), owner(username));
        return toResponse(tasks.save(t));
    }
    @Override @Transactional(readOnly = true)
    public List<TaskResponse> getAll(String username) {
        return tasks.findAllByUser_Username(username).stream().map(this::toResponse).toList();
    }
    @Override @Transactional(readOnly = true)
    public TaskResponse getOne(Long id, String username) { return toResponse(ownedTask(id, username)); }
    @Override public TaskResponse update(Long id, TaskRequest r, String username) {
        Task t = ownedTask(id, username);
        t.update(r.title(), r.description(), r.dueDate(),
            r.status() == null ? TaskStatus.TODO : r.status());
        return toResponse(tasks.save(t));
    }
    @Override public void delete(Long id, String username) { tasks.delete(ownedTask(id, username)); }
}
