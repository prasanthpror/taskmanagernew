package com.example.taskmanager.controller;

import com.example.taskmanager.dto.TaskRequest;
import com.example.taskmanager.dto.TaskResponse;
import com.example.taskmanager.service.TaskService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/tasks")
public class TaskController {
    private final TaskService taskService;
    public TaskController(TaskService taskService) { this.taskService = taskService; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TaskResponse create(@Valid @RequestBody TaskRequest request, Authentication auth) {
        return taskService.create(request, auth.getName());
    }
    @GetMapping
    public List<TaskResponse> getAll(Authentication auth) {
        return taskService.getAll(auth.getName());
    }
    @GetMapping("/{id}")
    public TaskResponse getOne(@PathVariable Long id, Authentication auth) {
        return taskService.getOne(id, auth.getName());
    }
    @PutMapping("/{id}")
    public TaskResponse update(@PathVariable Long id, @Valid @RequestBody TaskRequest request,
                               Authentication auth) {
        return taskService.update(id, request, auth.getName());
    }
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id, Authentication auth) {
        taskService.delete(id, auth.getName());
    }
}
